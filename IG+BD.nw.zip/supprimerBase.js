// Inclusion de Mongoose
var mongoose = require('mongoose');
// On se connecte à la base de données
// N'oubliez pas de lancer ~/mongodb/bin/mongod dans un terminal !
mongoose.connect('mongodb://localhost/base', function(err) {
  if (err) { throw err; }
});

// Création du schéma 
var BaseSchema = new mongoose.Schema({

  contenu : String,
  date : { type : Date, default : Date.now }
});

// Création du Model 
var UrlModel = mongoose.model('url', BaseSchema);


UrlModel.remove({ index : 'url' }, function (err) {
  if (err) { throw err; }
  console.log('les urls sont supprimer!');
});

UrlModel.remove({ index : 'page' }, function (err) {
  if (err) { throw err; }
  console.log('les pages sont supprimer !');
});


